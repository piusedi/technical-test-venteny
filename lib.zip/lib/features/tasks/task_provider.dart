import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'domain/entities/task.dart';

class TaskProvider with ChangeNotifier {
  late Box<Task> _taskBox;

  List<Task> get tasks => _taskBox.values.toList();

  Future<void> init() async {
    _taskBox = await Hive.openBox<Task>('tasks');
    notifyListeners();
  }

  Future<void> addTask(Task task) async {
    await _taskBox.add(task);
    notifyListeners();
  }

  Future<void> updateTask(Task task) async {
    await task.save();
    notifyListeners();
  }

  Future<void> deleteTask(Task task) async {
    await task.delete();
    notifyListeners();
  }
}
