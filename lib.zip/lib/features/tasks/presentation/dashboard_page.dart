import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../domain/entities/task.dart';
import '../task_provider.dart';  // Ensure this import points to the correct location

class DashboardPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Task Management')),
      body: Consumer<TaskProvider>(
        builder: (context, provider, child) {
          return ListView.builder(
            itemCount: provider.tasks.length,
            itemBuilder: (context, index) {
              final task = provider.tasks[index];
              return ListTile(
                title: Text(task.title),
                subtitle: Text(task.description ?? 'No description'),
                trailing: Text(task.status.toString().split('.').last),
                onTap: () {
                  _showTaskDialog(context, task);
                },
                onLongPress: () {
                  provider.deleteTask(task);
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showTaskDialog(context);
        },
        child: Icon(Icons.add),
      ),
    );
  }

  void _showTaskDialog(BuildContext context, [Task? task]) {
    final titleController = TextEditingController(text: task?.title ?? '');
    final descriptionController = TextEditingController(text: task?.description ?? '');
    DateTime selectedDate = task?.dueDate ?? DateTime.now();
    TaskStatus selectedStatus = task?.status ?? TaskStatus.pending;

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(task == null ? 'Add Task' : 'Edit Task'),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                decoration: InputDecoration(labelText: 'Title'),
              ),
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(labelText: 'Description'),
              ),
              ListTile(
                title: Text('Due Date: ${selectedDate.toLocal()}'),
                onTap: () async {
                  final DateTime? picked = await showDatePicker(
                    context: context,
                    initialDate: selectedDate,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2101),
                  );
                  if (picked != null && picked != selectedDate) {
                    selectedDate = picked;
                  }
                },
              ),
              DropdownButton<TaskStatus>(
                value: selectedStatus,
                onChanged: (TaskStatus? newStatus) {
                  selectedStatus = newStatus!;
                },
                items: TaskStatus.values.map((TaskStatus status) {
                  return DropdownMenuItem<TaskStatus>(
                    value: status,
                    child: Text(status.toString().split('.').last),
                  );
                }).toList(),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                if (task == null) {
                  final newTask = Task(
                    id: DateTime.now().toString(),
                    title: titleController.text,
                    description: descriptionController.text,
                    dueDate: selectedDate,
                    status: selectedStatus,
                  );
                  Provider.of<TaskProvider>(context, listen: false).addTask(newTask);
                } else {
                  task.title = titleController.text;
                  task.description = descriptionController.text;
                  task.dueDate = selectedDate;
                  task.status = selectedStatus;
                  Provider.of<TaskProvider>(context, listen: false).updateTask(task);
                }
                Navigator.pop(context);
              },
              child: Text(task == null ? 'Add' : 'Update'),
            ),
          ],
        );
      },
    );
  }
}
