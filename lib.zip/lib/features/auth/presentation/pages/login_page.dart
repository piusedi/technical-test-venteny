import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/login_bloc.dart';
import 'package:task_management_app/features/tasks/presentation/dashboard_page.dart'; // Pastikan pathnya benar
import 'package:email_validator/email_validator.dart'; // Import email_validator package

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool _isButtonPressed = false; // Track if the button was pressed

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            // Email Field with validation
            TextField(
              controller: emailController..text = 'eve.holt@reqres.in',
              decoration: InputDecoration(
                labelText: 'Email',
                errorText: _isButtonPressed ? _validateEmail(emailController.text) : null,
              ),
            ),
            // Password Field with validation
            TextField(
              controller: passwordController..text = 'cityslicka',
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Password',
                errorText: _isButtonPressed ? _validatePassword(passwordController.text) : null,
              ),
            ),
            SizedBox(height: 20),
            BlocConsumer<LoginBloc, String?>(
              listener: (context, state) {
                if (state != null && state.contains("Exception")) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(state.replaceAll("Exception: ", ""))),
                  );
                } else if (state != null && state.isNotEmpty) {
                  // Navigasi ke DashboardPage setelah login berhasil
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => DashboardPage()),
                  );
                }
              },
              builder: (context, state) {
                return ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _isButtonPressed = true; // Set to true when the button is pressed
                    });
                    if (_validateEmail(emailController.text) == null &&
                        _validatePassword(passwordController.text) == null) {
                      context.read<LoginBloc>().login(
                            emailController.text,
                            passwordController.text,
                          );
                    }
                  },
                  child: Text('Login'),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  // Validasi Email
  String? _validateEmail(String email) {
    if (email.isEmpty) {
      return 'Email tidak boleh kosong';
    } else if (!EmailValidator.validate(email)) {
      return 'Email tidak valid';
    }
    return null;
  }

  // Validasi Password
  String? _validatePassword(String password) {
    if (password.isEmpty) {
      return 'Password tidak boleh kosong';
    } else if (password.length < 8) {
      return 'Password harus minimal 8 karakter';
    }
    return null;
  }
}
