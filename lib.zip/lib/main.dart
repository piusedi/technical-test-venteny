import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:dio/dio.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'features/auth/presentation/pages/login_page.dart';
import 'features/auth/presentation/bloc/login_bloc.dart';
import 'features/auth/domain/usecases/login_usecase.dart';
import 'features/auth/data/datasources/auth_remote_datasource.dart';
import 'features/auth/data/repositories/auth_repository_impl.dart';
import 'features/tasks/domain/entities/task.dart';
import 'package:provider/provider.dart';
import 'features/tasks/task_provider.dart';

void main() async {
  final dio = Dio();
  final authRemoteDataSource = AuthRemoteDataSource(dio);
  final authRepository = AuthRepositoryImpl(authRemoteDataSource);
  final loginUseCase = LoginUseCase(authRepository);

  await Hive.initFlutter();
  Hive.registerAdapter(TaskStatusAdapter()); // Register TaskStatusAdapter
  Hive.registerAdapter(TaskAdapter()); // Register TaskAdapter
  await Hive.openBox<Task>('tasks');

  runApp(MyApp(loginUseCase));
}

class MyApp extends StatelessWidget {
  final LoginUseCase loginUseCase;

  const MyApp(this.loginUseCase, {super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => TaskProvider()),  // Provide TaskProvider to the app
      ],
      child: BlocProvider(
        create: (_) => LoginBloc(loginUseCase),
        child: MaterialApp(
          home: LoginPage(),
        ),
      ),
    );
  }
}
